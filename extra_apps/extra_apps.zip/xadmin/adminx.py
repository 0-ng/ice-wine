from __future__ import absolute_import
import xadmin
from .models import UserSettings, Log
from xadmin.layout import *

from django.utils.translation import ugettext_lazy as _, ugettext

class UserSettingsAdmin(object):
    model_icon = 'fa fa-cog'
    hidden_menu = True

xadmin.site.register(UserSettings, UserSettingsAdmin)

class LogAdmin(object):

    def link(self, instance):
        if instance.content_type and instance.object_id and instance.action_flag != 'delete':
            admin_url = self.get_admin_url('%s_%s_change' % (instance.content_type.app_label, instance.content_type.model), 
                instance.object_id)
            return "<a href='%s'>%s</a>" % (admin_url, _('Admin Object'))
        else:
            return ''
    link.short_description = ""
    link.allow_tags = True
    link.is_column = False

    list_display = ('action_time', 'user', 'ip_addr', '__str__', 'link')
    list_filter = ['user', 'action_time']
    search_fields = ['ip_addr', 'message']
    model_icon = 'fa fa-cog'

xadmin.site.register(Log, LogAdmin)


# 设计左侧菜单
class GlobalSetting(object):  #名称不能改
    def get_site_menu(self):  #名称不能改
        return [
            {
                'title': '测试的',
                'icon': 'fa fa-bar-chart-o',
                'menus': (
                    {
                        'title': '员工业绩分析',    #这里是你菜单的名称
                        'url': '/xadmin/employee_performance_analysis',     #这里填写你将要跳转url
                        'icon': 'fa fa-cny'     #这里是bootstrap的icon类名，要换icon只要登录bootstrap官网找到icon的对应类名换上即可
                    },
                    {
                        'title': '商品销量分析',
                        'url': '/xadmin/sales_performance_analysis',
                        'icon': 'fa fa-cny'
                    }
                )
            }
        ]


#注册GlobalSetting
# from luogu.views import employee_performance_analysis   #从你的app的view里引入你将要写的view，你也可以另外写一个py文件，把后台的view集中在一起方便管理
# from luogu.views import sales_performance_analysis   #从你的app的view里引入你将要写的view，你也可以另外写一个py文件，把后台的view集中在一起方便管理
# xadmin.site.register_view(r'employee_performance_analysis/$', employee_performance_analysis, name='for_test')
# xadmin.site.register_view(r'sales_performance_analysis/$', sales_performance_analysis, name='for_test')
#
# from xadmin.views import CommAdminView
# xadmin.site.register(CommAdminView, GlobalSetting)





